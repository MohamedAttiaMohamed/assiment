package com.example.assiment_screen

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
